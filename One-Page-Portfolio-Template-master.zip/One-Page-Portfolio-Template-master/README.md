# Free Bootstrap One-Page Portfolio Template

### Preview
[![Demo - Free Bootstrap One-Page Portfolio Template](http://designerdada.com/designerdada/wp-content/uploads/2017/04/One-Page-Portfolio-Free-Bootstrap-Template.jpg)](http://www.designerdada.com/designerdada/dd-repository/One-Page-Portfolio-Template/index.html)

### Features

* Free one-page template
* Built with Bootstrap
* 100% mobile-friendly
* Case study and Testimonial sliders
* Animated counter-up statistics section
* PSD files included


### Credits

 * [Swiper - Most modern mobile touch slider](http://idangero.us/swiper)
 * [Counterup.js](https://github.com/bfintal/Counter-Up) by [Benjamin Intal](https://github.com/bfintal)


### Designed by

 * Vijay Verma [@realvjy](https://dribbble.com/realvjy)

### Developed by

 * Akash Bhadange [@designerdada](https://dribbble.com/designerdada)

### Links
 * Blog Post - http://designerdada.com/free-bootstrap-one-page-portfolio-template/
 * Demo - http://www.designerdada.com/designerdada/dd-repository/One-Page-Portfolio-Template/index.html
 * Download - https://github.com/designerdada/One-Page-Portfolio-Template/archive/master.zip

### License
MIT License 2017 | All creative rights by [@realvjy](https://github.com/realvjy)
